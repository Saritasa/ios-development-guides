//
//  ViewController.swift
//  locationtracker
//
//  Created by Алексей on 07.04.17.
//  Copyright © 2017 Saritasa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    // MARK: - UI Elements
    
    @IBOutlet fileprivate var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
    }
    
    
    // MARK: - UI Actions
    
    @IBAction fileprivate func refreshData() {
        loadData()
    }
    
    
    // MARK: - Private Functions
    
    fileprivate func loadData() {
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let path = dir.appendingPathComponent("logfile.txt")
            
            do {
                let text = try String(contentsOf: path, encoding: String.Encoding.utf8)
                textView.text = text
            }
            catch let error {
                textView.text = error.localizedDescription
            }
        }
    }

}
