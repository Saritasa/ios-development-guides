//
//  LocationManager.swift
//  locationtracker
//
//  Created by Алексей on 07.04.17.
//  Copyright © 2017 Saritasa. All rights reserved.
//

import UIKit
import CoreLocation
import JLocationKit


class INTLocationManager: NSObject {
    
    
    // MARK: - Properties
    
    /// Singleton
    static let shared = INTLocationManager()
    
    // location manager for updating location
    fileprivate let locationManager = LocationManager()
    
    /// A time interval between location updates. Default value is 300 seconds
    var locationUpdatesInterval: Int = 300
    
    // background task identifier for checking when the app is inactive
    fileprivate var backgroundTaskID: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid
    
    
    // MARK: - Initialization
    
    private override init() {
        super.init()
        
        setup()
        
        NotificationCenter.default.addObserver(forName: Notification.Name.UIApplicationDidEnterBackground, object: nil, queue: nil) { (notification) in
            self.startUpdatingLocations()
        }
        
        NotificationCenter.default.addObserver(forName: Notification.Name.UIApplicationDidBecomeActive, object: nil, queue: nil) { (notification) in
            self.startUpdatingLocations()
        }
    }
    
    fileprivate func setup() {
        startMonitoringSignificantLocationChanges()
    }
    
    
    // MARK: - Public Functions
    
    /// Starts updating locations: launchs one shot getting locations between time interval specified in 'locationUpdatesInterval'
    func startUpdatingLocations() {
        if isInBackground() {
            startMonitoringSignificantLocationChanges()
        } else {
            getLocation()
        }
    }
    
    
    // MARK: - Private Functions
    
    fileprivate func getLocation() {
        locationManager.getLocation(detectStyle: .Once, distanceFilter: 250, detectFrequency: locationUpdatesInterval, completion: { (locationResponse) in
            // success updating location
            self.saveLocation(response: locationResponse)
            self.scheduleGettingLocation()
            
            if self.isInBackground() {
                self.endBackgroundTask()
            }
            
        }, error: { (error) in
            // failed updating location
            _log(text: "Failed updating location: \(error)")
            self.scheduleGettingLocation()
            
            if self.isInBackground() {
                self.endBackgroundTask()
            }
        })
    }
    
    fileprivate func scheduleGettingLocation() {
        delay(TimeInterval(self.locationUpdatesInterval), closure: {
            self.startUpdatingLocations()
        })
    }
    
    /// starts monitoring signification location changes for constantly checking location updates
    fileprivate func startMonitoringSignificantLocationChanges() {
        backgroundTaskID = UIApplication.shared.beginBackgroundTask(expirationHandler: {
            UIApplication.shared.endBackgroundTask(self.backgroundTaskID)
            _log(text: "Did finish background task \(self.backgroundTaskID)")
        })
        _log(text: "Did start background task \(backgroundTaskID)")
        
        locationManager.getLocation(detectStyle: .SignificantLocationChanges, distanceFilter: 0, detectFrequency: 0, completion: { (locationResponse) in
            // success updating location
            self.saveLocation(response: locationResponse)
            
        }, error: { (error) in
            // failed updating location
            _log(text: "Failed updating location: \(error)")
        })
    }
    
    fileprivate func saveLocation(response: JLocationResponse) {
        if let location = response.currentLocation {
            let distance = response.distanceInterval ?? -1
            _log(text: "Save location: (\(location.coordinate.latitude), \(location.coordinate.longitude)), accuracy: \(location.horizontalAccuracy), timestamp: \(location.timestamp), distance: \(distance)")
            
        } else {
            _log(text: "Location data isn't valid")
        }
    }
    
    fileprivate func isInBackground() -> Bool {
        return UIApplication.shared.applicationState == UIApplicationState.background
    }
    
    fileprivate func endBackgroundTask() {
        if backgroundTaskID != UIBackgroundTaskInvalid {
            UIApplication.shared.endBackgroundTask(backgroundTaskID)
            _log(text: "Did finish background task \(backgroundTaskID)")
            backgroundTaskID = UIBackgroundTaskInvalid
        }
    }
    
    
    // MARK: - Deinit
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
}
