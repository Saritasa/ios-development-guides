//
//  Utils.swift
//  locationtracker
//
//  Created by Алексей on 07.04.17.
//  Copyright © 2017 Saritasa. All rights reserved.
//

import Foundation


func delay(_ delay: TimeInterval, closure:@escaping ()->()) {
    DispatchQueue.main.asyncAfter(
        deadline: DispatchTime.now() + Double(Int64(delay * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: closure)
}

func _log(text: String) {
    addLog(text: text)
    debugPrint(text)
}

func addLog(text: String) {
    let dir = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask).first!
    
    let fileurl =  dir.appendingPathComponent("logfile.txt")
    
    let string = "\(Date()) | \(text)\n"
    let data = string.data(using: .utf8, allowLossyConversion: false)!
    
    if FileManager.default.fileExists(atPath: fileurl.path) {
        if let fileHandle = try? FileHandle(forUpdating: fileurl) {
            fileHandle.seekToEndOfFile()
            fileHandle.write(data)
            fileHandle.closeFile()
        }
        
    } else {
        try! data.write(to: fileurl, options: Data.WritingOptions.atomic)
    }
}
